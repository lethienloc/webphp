<?php
$servername = "localhost";
$database = "id15087001_loc";
$username = "id15087001_loclop1";
$password = "eM7OzM(CEDBu&Awj";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
$conn->set_charset("utf8");

?>