

<div id="templatemo_header">
    	
        
        
      </div> <!-- end of header -->
	  <div id="templatemo_menu">
        <ul>
            <li><a href="index.php" class="current">Trang chủ</a></li>
            <li><a href="index.php?loaisp=apple">Apple</a></li>
            <li><a href="index.php?loaisp=asus">Asus</a></li>
            <li><a href="index.php?loaisp=dell">Dell</a></li>
			<li><a href="dangnhap.php">Đăng Nhập</a></li>
			<li><a href="dangky.php">Đăng ký</a></li>
        </ul>    	
    </div> <!-- end of menu -->